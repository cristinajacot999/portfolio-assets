export type Category = 'Moving Image' | 'Social Infrastructure' | 'Habitats' | 'Sonic Cartography';

export interface ExternalLink {
  label: string;
  url: string;
}

export interface Testimony {
  quote: string;
  author: string;
}

export interface Project {
  id: string;
  title: string;
  year: string;
  role?: string; // New property for visual roles box
  category: Category;
  shortCaption: string;
  longDescription: string;
  imageUrl: string;
  imagePosition?: 'left' | 'center' | 'right'; // Added for specific preview alignment
  galleryImages: string[];
  externalLinks?: ExternalLink[];
  testimonies?: Testimony[];
  themeColor?: string; // Hex for the pastel background of the detail page
}

export interface SiteContent {
  author: string;
  landing: {
    line1: string;
    line2: string;
    buttonText: string;
  };
  about: {
    text: string;
    image: string;
  };
  contact: {
    email: string;
    instagram: string;
  };
  projects: Project[];
}