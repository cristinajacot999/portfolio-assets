import { SiteContent } from './types';

export const CONTENT_STORE: SiteContent = {
  author: "CRISTINA JACOT",
  landing: {
    line1: "Hi, I'm Cristina, and I'm a witch.",
    line2: "Just kidding :) I’m an artist. Being one can be just as hard to define, but just as whimsical.",
    buttonText: "See the magic"
  },
  about: {
    text: "Cristina is a cultural worker and filmmaker. Specializing in DIY approaches, she designs and builds temporary structures (pop-up cafés, libraries, and cinemas) that fulfill real, urgent needs.\n\nHer practice is rooted in spacemaking: transforming dormant or empty environments into vital community hubs where life and creativity are allowed to happen unscripted.\n\nCentral to her practice is the study of the audience as a living organism. She plays with the tension between attention and intention.\n\nCristina’s recent practice explores food as a primary medium. By treating nourishment as both a necessity and a constant generator of choices, she creates immersive \"food for thought\" experiences.",
    image: "https://github.com/cristinajacot999/portfolio-assets/blob/main/ADO04518.jpg?raw=true"
  },
  contact: {
    email: "hello@cristinajacot.com",
    instagram: "@fata.cu.caii"
  },
  projects: [
    // --- MOVING IMAGE ---
    {
      id: "we-lived-slowly",
      title: "We Lived Slowly in Times of Peace",
      year: "2025",
      role: "Director, Editor",
      category: "Moving Image",
      shortCaption: "",
      longDescription: "Based on Tatev Chakhian’s poem \"Retrospective\", the film unravels the bittersweet stillness of peace, where the comforts of routine mask the erosion of time while the quiet tension of war lingers in the air.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/films/peace/peace%201.jpg?raw=true",
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/films/peace/peace%201.jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/films/peace/peace%202.png?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/films/peace/peace%203.png?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/films/peace/peace%204.jpg?raw=true"
      ],
      themeColor: "#FDF2F7",
      externalLinks: [
        { label: "Article (RO)", url: "https://specialarad.ro/stiri-ratate-42-lumea-ireala-propaganda-pace-murim/" },
        { label: "Article (PT)", url: "https://tribunadocinema.com/especial-beast-international-film-festival/" },
        { label: "Announcement (DE)", url: "https://www.hausfuerpoesie.org/de/programm/zebra-poetry-film-festival-hauntings/" },
        { label: "Interview (RU)", url: "https://locals.md/2025/kristina-jacot/" },
        { label: "Interview (RO)", url: "https://diez.md/2025/10/25/un-scurtmetraj-moldovenesc-a-fost-desemnat-cel-mai-bun-la-un-festival-din-romania-cand-va-fi-proiectat-la-chisinau/" }
      ],
      testimonies: [
        {
          author: "Tribuna do Cinema",
          quote: "A powerful testament to the value of tension in cinema... reconfiguring everything we feel when revisiting normalcy, now with the ghost of war hovering in the air."
        }
      ]
    },
    {
      id: "monster-near-mother",
      title: "A Monster near my Mother's Heart",
      year: "2023",
      role: "Director, Editor, Animator",
      category: "Moving Image",
      shortCaption: "",
      longDescription: "An intimate exploration of a mother-daughter relationship that bridges cinema with real-life vulnerability. The film uses water as a primary animation element, with dynamic watercolor strokes superimposed onto personal archive footage to navigate childhood memories and the reality of illness.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/films/monster/monster%20(1).jpg?raw=true",
      imagePosition: 'left',
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/films/monster/monster%20(1).jpg?raw=true"
      ],
      themeColor: "#F2F5FD",
      externalLinks: [
        { label: "Article (RO)", url: "https://www.acoperisuldesticla.ro/film/cinemaiubit-2023-off-the-script-mama-tata-bunica-si-existentialismul-5073/" }
      ],
      testimonies: [
        {
          author: "Acoperișul de Sticlă",
          quote: "A unique hybridization of documentary and animation... a complete vulnerability in the face of human infirmity, a heavy realization that becomes the common denominator haunting these cinematic micro-universes."
        }
      ]
    },
    // --- SONIC CARTOGRAPHY ---
    {
      id: "between-cracks",
      title: "Between Cracks",
      year: "2024",
      role: "Producer",
      category: "Sonic Cartography",
      shortCaption: "",
      longDescription: "An independent radio series dedicated to the hidden locations, grassroots initiatives, and cultural phenomena of Moldova. The project serves as an attempt to look \"between the cracks\" of cultural centers, exploring them as both physical environments and imaginary structures across five distinct episodes.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/cracks/photo_2023-02-12_16-04-57.jpg?raw=true",
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/cracks/photo_2023-02-12_16-04-57.jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/cracks/unnamed.jpg?raw=true"
      ],
      themeColor: "#F5F5F5",
      externalLinks: [
        { label: "Radio Show", url: "https://soundcloud.com/coali-ia-sectorului-cultural-independent/sets/radio-show-printre-cr-p-turi-5" }
      ]
    },
    {
      id: "chisinaul-meu-cel-mic",
      title: "Chisinăul Meu Cel Mic",
      year: "2025",
      role: "Co-producer, Sound editor",
      category: "Sonic Cartography",
      shortCaption: "",
      longDescription: "This project is a sonic exploration of the Moldovan capital, functioning as a \"tourist guide for the uninvited\". By moving away from monuments and toward peripheral sounds, oral histories, and the quiet rhythms of daily life, the series deconstructs Chisinau’s identity. It serves as an auditory \"ephemeral structure,\" using field recordings and curated soundtracks to build a mental map of a city caught between nostalgia and transition.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/radio/radio%20(1).JPEG?raw=true",
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/radio/radio%20(1).JPEG?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/radio/radio%20(2).JPEG?raw=true"
      ],
      themeColor: "#F2F2F2",
      externalLinks: [
        { label: "Radio (EN)", url: "https://cashmereradio.com/episode/office-for-joint-administrative-intelligence-70-chisinaul-meu-cel-mic/" },
        { label: "Radio (EN)", url: "https://mixes.vuiz.net/DublinDigitalRadio/chisinaul-meu-cel-mic-ojaino-tourists-aug-2025" },
        { label: "Radio (EN)", url: "https://blackrhinoradio.com/radio/shows/chisinaul-meu-cel-mic" }
      ]
    },
    // --- SOCIAL INFRASTRUCTURE ---
    {
      id: "bioskop",
      title: "Bioskop",
      year: "2024 – 2025",
      role: "Co-founder, Artistic Director",
      category: "Social Infrastructure",
      shortCaption: "",
      longDescription: "Bioskop is a Chisinau-based collective dedicated to reimagining the cinematic experience through grassroots, community-driven screenings.\n\n### Film+Food\nAs an extension of this mission, the Film + Food series investigated the ethics of consumption by removing the \"fourth wall\". Through experiments like live ramen preparation during screenings or potluck events highlighting \"invisible labor,\" the project forced the audience to engage with the physical and cultural reality of what they consume.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/bioksop/bioskop%20(2).jpg?raw=true",
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/bioksop/bioskop%20(2).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/bioksop/bioskop%20(4).JPG?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/experience%20design/film+food/food%20(2).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/experience%20design/film+food/food%20(3).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/experience%20design/film+food/food%20(5).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/experience%20design/film+food/food%20(1).jpg?raw=true"
      ],
      themeColor: "#F2F5FD",
      externalLinks: [
        { label: "Instagram Page (EN)", url: "https://www.instagram.com/klub_bioskop/" },
        { label: "Telegram Page (EN)", url: "https://t.me/Bioskop_announcements" },
        { label: "Podcast (EN)", url: "https://www.youtube.com/watch?v=wOK4A1Jujgc" }
      ]
    },
    {
      id: "horse-sanctuary",
      title: "Horse Sanctuary",
      year: "2018 – 2019",
      role: "Co-Founder, Development Manager",
      category: "Social Infrastructure",
      shortCaption: "",
      longDescription: "Founded as an immediate response to systemic failure, this sanctuary rescued four horses destined for slaughter after a local farm closure. The project was a visceral exercise in \"functional ephemerality,\" requiring rapid infrastructure development and the physical construction of a home from the ground up to create a safe, respectful environment away from exploitation.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/sanctuary/sanctuary%20(3).jpg?raw=true",
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/sanctuary/sanctuary%20(3).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/sanctuary/sanctuary%20(4).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/sanctuary/sanctuary%20(6).JPG?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/sanctuary/sanctuary%20(7).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/sanctuary/sanctuary%20(1).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/initiatives/sanctuary/sanctuary%20(2).jpg?raw=true"
      ],
      themeColor: "#FDF2F2",
      externalLinks: [
        { label: "GlobalGiving (EN)", url: "https://www.globalgiving.org/projects/horse-sanctuary/" },
        { label: "Video reportage (RO)", url: "https://moldova.europalibera.org/a/refugiul-cailor-pur-%C5%9Fi-simplu/30151473.html" },
        { label: "Article (EN)", url: "https://www.ecovisio.org/what-we-do/project/horse-sanctuary-riscova" },
        { label: "Instagram (EN)", url: "https://www.instagram.com/humansandhorses/" }
      ]
    },
    // --- HABITATS ---
    {
      id: "3rd-space",
      title: "3rd Space",
      year: "2020 – 2023",
      role: "Resident curator",
      category: "Habitats",
      shortCaption: "",
      longDescription: "Operated by the Drujba art collective within the Zemstvei Cultural Center, this was an open-access, collaborative studio dedicated to independent publishing and DIY media. The studio utilized typewriters and manual printing to foster grassroots creativity. When the aging infrastructure of the historic building led to dangerous leaks, the practice shifted entirely to the Zemstvei Garden as an act of resilience. By moving outdoors, the project proved that a creative ecosystem is defined by its people and shared practice rather than its physical walls.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/garden/space%20(2).jpg?raw=true",
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/garden/photo_599@03-10-2022_20-21-20.jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/garden/space%20(1).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/garden/space%20(2).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/garden/space%20(3).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/garden/space%20(4).jpg?raw=true"
      ],
      themeColor: "#F2FDF2",
      externalLinks: [
        { label: "Description (EN)", url: "https://telegra.ph/DRUJBA--3RD-SPACE-05-19" },
        { label: "Podcast (EN)", url: "https://www.youtube.com/watch?v=qHhkulwQE7s" }
      ]
    },
    {
      id: "3rd-space-library",
      title: "Open Library",
      year: "2020 – 2023",
      role: "Founder, Coordinator",
      category: "Habitats",
      shortCaption: "",
      longDescription: "Born from the same need for independent resources in Chisinau, the 3rd Space Library functions as an extension of this collaborative environment. By reactivating materials available at the independent publishing studio, the project organized an open library system. It currently consists of over 100 books and 150 rare international publications, making specialized knowledge accessible to the local community.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/photo_1490@14-04-2023_10-45-00.jpg?raw=true",
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/photo_1490@14-04-2023_10-45-00.jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/IMG_7696.JPEG?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/library%20(2).jpg?raw=true"
      ],
      themeColor: "#F9F2FD"
    },
    {
      id: "vivid-xx",
      title: "Vivid XX",
      year: "2022",
      role: "Residency participant",
      category: "Habitats",
      shortCaption: "",
      longDescription: "Expanding the investigation of space beyond the studio, Vivid XX was set on the grounds of an abandoned Soviet workers' sanatorium. Occupying two empty rooms, the residency investigated the balance between work, life, and rest. These rooms became a 'live' exhibition, evolving through daily contributions from visitors and blurring the line between domestic existence and public performance.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/vivid/vivid%20(1).JPEG?raw=true",
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/vivid/vivid%20(1).JPEG?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/vivid/vivid%20(1).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/vivid/vivid%20(2).JPEG?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/vivid/vivid%20(3).JPEG?raw=true"
      ],
      themeColor: "#F2FDFD"
    },
    {
      id: "caiet-cornet",
      title: "Caiet Cornet",
      year: "2023",
      role: "Residency participant",
      category: "Habitats",
      shortCaption: "",
      longDescription: "This project continued the exploration of collective living by transforming a residential house into a temporary laboratory. As an Artist-in-Residence with the Drujba and L1 Collectives, the focus shifted to co-habitation as a creative catalyst. By finding the 'intersection of friction' where different practices meet, the residency culminated in a site-specific exhibition and a collaborative publication.",
      imageUrl: "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/caiet/caiet%20(3).JPG?raw=true",
      galleryImages: [
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/caiet/caiet%20(1).jpg?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/caiet/caiet%20(2).JPG?raw=true",
        "https://github.com/cristinajacot999/portfolio-assets/blob/main/spacemaking/caiet/caiet%20(3).JPG?raw=true"
      ],
      themeColor: "#F5F2FD",
      externalLinks: [
        { label: "Article (RO)", url: "https://www.igloo.ro/dincolo-de-mine-suntem-noi-rezidenta-transnationala-despre-practici-colaborative-si-diy-in-arta-care-deschide-anexa-matka/" }
      ]
    }
  ]
};