import React, { useState, useEffect } from 'react';
import { motion, useSpring, useMotionValue } from 'framer-motion';
import { Project } from '../types';

const PolaroidCursor: React.FC = () => {
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 20, stiffness: 150 };
  const smoothX = useSpring(mouseX, springConfig);
  const smoothY = useSpring(mouseY, springConfig);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
    };

    const handleProjectHover = (e: CustomEvent<Project | null>) => {
      setActiveProject(e.detail);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('project-hover', handleProjectHover as EventListener);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('project-hover', handleProjectHover as EventListener);
    };
  }, [mouseX, mouseY]);

  return (
    <motion.div
      style={{
        position: 'fixed',
        left: 0,
        top: 0,
        x: smoothX,
        y: smoothY,
        pointerEvents: 'none',
        zIndex: 50,
      }}
      className="hidden lg:block"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
        animate={{ 
          opacity: activeProject ? 1 : 0, 
          scale: activeProject ? 1 : 0.8,
          rotate: activeProject ? 4 : -5,
          y: -100, // Offset from cursor
          x: 20
        }}
        transition={{ type: 'spring', damping: 15 }}
        // Polaroid Styling
        className="bg-white px-3 pt-3 pb-12 shadow-2xl border border-stone-100 w-64"
      >
        <div className="relative aspect-[4/5] overflow-hidden bg-stone-100 group">
          {activeProject && (
            <img 
              src={activeProject.imageUrl} 
              alt={activeProject.title}
              // Enhanced Haze & Unified Aesthetic: warm wash, low contrast, blur
              // Dynamic positioning support
              className={`w-full h-full object-cover contrast-[0.85] brightness-[1.02] sepia-[0.3] saturate-[0.8] blur-[0.6px] ${
                activeProject.imagePosition === 'left' ? 'object-left' : 
                activeProject.imagePosition === 'right' ? 'object-right' : 'object-center'
              }`}
            />
          )}
          {/* Grain & Light Leak simulation */}
          <div className="absolute inset-0 bg-gradient-to-tr from-[#E6D5B8]/10 via-transparent to-white/20 opacity-40 mix-blend-screen" />
          <div className="absolute inset-0 opacity-[0.05] pointer-events-none" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%' height='100%' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }} />
        </div>
      </motion.div>
    </motion.div>
  );
};

export default PolaroidCursor;