import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CONTENT_STORE } from '../constants';

const Header: React.FC = () => {
  const location = useLocation();

  // Determine if we are on a project detail page
  const isProjectPage = location.pathname.startsWith('/project/');
  
  // Specific color for "CRISTINA JACOT" - White on Index, Slate Gray on Projects
  const logoColorClass = isProjectPage ? 'text-slate-700' : 'text-white';
  
  // Navigation text color - White on Index, Slate Gray/Indigo on Projects
  const navColorClass = isProjectPage ? 'text-slate-600' : 'text-white';
  const navHoverClass = isProjectPage ? 'hover:bg-slate-700/10' : 'hover:bg-white/20';

  const navItems = [
    { name: 'INDEX', path: '/' },
    { name: 'INFO', path: '/about' },
    { name: 'SAY HI', path: '/contact' },
  ];

  return (
    <header className="fixed top-0 left-0 w-full z-40 p-6 md:p-8">
      <div className="flex justify-between items-center">
        <Link to="/" className="group">
          <motion.h1 
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className={`text-2xl md:text-3xl font-bold tracking-tighter transition-colors duration-500 ${logoColorClass}`}
          >
            {CONTENT_STORE.author}
          </motion.h1>
        </Link>

        <nav className="flex gap-4 md:gap-8 text-xs font-bold uppercase tracking-widest">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            
            return (
              <Link 
                key={item.path} 
                to={item.path}
                className={`px-3 py-1 transition-all duration-500 ${
                  isActive 
                  ? (isProjectPage ? 'bg-slate-700 text-white' : 'bg-white text-[#D4447A]') 
                  : `${navColorClass} ${navHoverClass}`
                }`}
              >
                {item.name}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
};

export default Header;