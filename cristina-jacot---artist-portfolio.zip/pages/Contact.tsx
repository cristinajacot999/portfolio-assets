
import React from 'react';
import { motion } from 'framer-motion';

const Contact: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    // We allow the default behavior if we want standard Netlify form submission, 
    // or we can handle it via fetch if we want to stay on the page.
    // For simplicity with "data-netlify", standard HTML submission is often preferred 
    // but in a SPA, we usually use fetch. However, adding the attributes allows Netlify 
    // to detect the form at build time.
    
    // If the user wants to keep the mailto logic, they can, but Netlify won't capture the data.
    // To allow Netlify to capture data, we'll let the form submit normally or use fetch.
    // Given the prompt "allow Netlify to handle submissions", I will modify this to 
    // be compatible with Netlify's requirements.
  };

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen flex items-center justify-center p-6 bg-[#D4447A]"
    >
      <div className="w-full max-w-lg relative">
        <motion.div 
          className="relative bg-white p-8 md:p-12 shadow-2xl"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <div className="border-b-4 border-[#D4447A] pb-6 mb-10 flex flex-col items-start gap-4">
            <h2 className="header-font text-3xl md:text-4xl lg:text-5xl text-[#D4447A] leading-tight tracking-tighter uppercase">POST-ART<br/>CORRESPONDENCE</h2>
          </div>

          <form 
            name="contact" 
            method="POST" 
            data-netlify="true" 
            netlify-honeypot="bot-field"
            className="space-y-8"
          >
            {/* Netlify hidden fields */}
            <input type="hidden" name="form-name" value="contact" />
            <p className="hidden">
              <label>
                Don’t fill this out if you’re human: <input name="bot-field" />
              </label>
            </p>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">Your Email</label>
              <input 
                required
                type="email" 
                name="email"
                placeholder="mail@address.com"
                className="w-full bg-stone-50 border-2 border-stone-100 p-4 focus:border-[#D4447A] outline-none text-[#2D1B69] font-medium"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">Your Message</label>
              <textarea 
                required
                name="message"
                rows={5}
                placeholder="Write your message here..."
                className="w-full bg-stone-50 border-2 border-stone-100 p-4 focus:border-[#D4447A] outline-none text-[#2D1B69] resize-none font-medium"
              />
            </div>
            <div className="pt-4">
              <button type="submit" className="w-full bg-[#D4447A] text-white py-5 font-bold text-sm tracking-[0.4em] hover:bg-[#2D1B69] transition-colors shadow-lg uppercase">
                Send Letter
              </button>
            </div>
          </form>
        </motion.div>

        {/* Shadow/Envelope Backing */}
        <div className="absolute inset-0 bg-[#2D1B69] -z-10 translate-x-4 translate-y-4" />
      </div>
    </motion.main>
  );
};

export default Contact;
