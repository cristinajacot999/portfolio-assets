import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { CONTENT_STORE } from '../constants';

const ProjectDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const project = CONTENT_STORE.projects.find((p) => p.id === id);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!project) return <div className="p-20 text-white font-mono">Project not found</div>;

  const numImages = project.galleryImages.length;
  const isBetweenCracks = project.id === 'between-cracks';

  /**
   * Internal Cross-Linking & Formatting Logic
   */
  const renderDescription = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      if (line.startsWith('###')) {
        return (
          <h3 key={idx} className="text-sm lg:text-base font-bold uppercase tracking-[0.2em] text-[#D4447A] mt-8 mb-4 border-b border-[#D4447A]/20 pb-2">
            {line.replace('###', '').trim()}
          </h3>
        );
      }
      
      const parts = line.split(/(3rd Space Library)/g);
      return (
        <p key={idx} className="mb-4 last:mb-0 text-justify">
          {parts.map((part, i) => {
            if (part === "3rd Space Library") {
              return (
                <Link 
                  key={i} 
                  to="/project/3rd-space-library" 
                  className="underline decoration-[#D4447A] decoration-2 underline-offset-4 hover:text-[#D4447A] transition-colors font-bold"
                >
                  {part}
                </Link>
              );
            }
            return part;
          })}
        </p>
      );
    });
  };

  /**
   * REFINED GALLERY SIZING LOGIC
   * Aimed at ensuring no vertical scroll and maintaining "Museum Catalogue" minimalism.
   */
  const getBaseHeight = () => {
    if (isBetweenCracks) return 'h-[35%] lg:h-[40%]'; // Specific reduced height for 30% viewport width feel
    if (numImages <= 2) return 'h-[40%] lg:h-[50%]';
    if (numImages <= 4) return 'h-[30%] lg:h-[40%]';
    if (numImages <= 6) return 'h-[25%] lg:h-[30%]';
    return 'h-[18%] lg:h-[22%]';
  };

  const baseHeightClass = getBaseHeight();

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="h-screen w-screen overflow-hidden flex flex-col pt-24"
      style={{ backgroundColor: project.themeColor || '#FDF2F7' }}
    >
      {/* Lightbox */}
      <AnimatePresence>
        {lightboxImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setLightboxImage(null)}
            className="fixed inset-0 z-[100] bg-stone-900/95 flex items-center justify-center p-8 cursor-zoom-out"
          >
            <motion.img
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              src={lightboxImage}
              className="max-w-full max-h-full object-contain shadow-2xl"
            />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col md:flex-row px-6 md:px-12 pb-12 gap-8 lg:gap-12 min-h-0">
        
        {/* Left: Info Column */}
        <div className="flex-none w-full md:w-72 lg:w-96 flex flex-col h-full">
          <div className="space-y-4 mb-6 shrink-0">
            <Link to="/" className="text-[10px] font-bold uppercase tracking-widest text-[#D4447A] hover:text-[#2D1B69] transition-colors">
              ← INDEX / {project.category}
            </Link>
            <div className="space-y-3">
              <div className="space-y-1">
                <h1 className="header-font text-3xl md:text-4xl lg:text-5xl text-[#2D1B69] leading-[0.85] tracking-tighter uppercase break-words">
                  {project.title}
                </h1>
                <p className="text-sm md:text-base font-light italic text-[#2D1B69] opacity-70">
                  {project.year}
                </p>
              </div>

              {project.role && (
                <div className="inline-block bg-[#2D1B69] text-white px-3 py-1.5 border-l-4 border-[#D4447A] shadow-sm">
                  <span className="text-[10px] font-bold uppercase tracking-[0.2em] leading-none">
                    {project.role}
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto pr-4 custom-scrollbar">
            {project.id === 'we-lived-slowly' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-8 p-4 bg-[#C5A059]/10 border border-[#C5A059] flex flex-col items-center gap-2 text-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#C5A059" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mb-1">
                  <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path>
                  <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path>
                  <path d="M4 22h16"></path>
                  <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"></path>
                  <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"></path>
                  <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"></path>
                </svg>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#C5A059]">
                  Winner of Best Short Film Award at the fARAD International Film Festival
                </span>
              </motion.div>
            )}

            <div className="text-xs lg:text-sm font-medium leading-relaxed text-[#2D1B69] space-y-2 whitespace-pre-wrap text-justify">
              {renderDescription(project.longDescription)}
            </div>

            {project.testimonies && project.testimonies.length > 0 && (
              <div className="mt-8 pt-8 border-t border-[#2D1B69]/10 space-y-8 pb-12">
                <h4 className="text-[10px] font-bold text-[#D4447A] uppercase tracking-widest">Testimonies</h4>
                {project.testimonies.map((testimony, idx) => (
                  <div key={idx} className="space-y-3">
                    <p className="text-xs lg:text-sm italic leading-relaxed text-[#2D1B69] opacity-80 text-justify">
                      "{testimony.quote}"
                    </p>
                    <p className="text-[10px] font-bold uppercase tracking-wider text-[#D4447A]/70">
                      — {testimony.author}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Center: Minimalist Standard Photos (No Polaroid Effect) */}
        <div className="flex-1 min-h-0 relative h-full overflow-hidden">
            <div className={`flex flex-wrap gap-8 content-start items-start justify-start h-full w-full overflow-hidden ${isBetweenCracks ? 'justify-center items-center' : ''}`}>
              {project.galleryImages.map((img, idx) => {
                const subtleRotate = (idx % 3 - 1) * 1.5;

                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1, duration: 0.8 }}
                    // Minimalist Border (no Polaroid spacing/haze)
                    className={`relative cursor-zoom-in group border-2 border-white/40 shadow-sm shrink-0 overflow-hidden ${baseHeightClass} ${isBetweenCracks ? 'max-w-[30vw]' : ''}`}
                    style={{
                      transform: `rotate(${subtleRotate}deg)`,
                      zIndex: 10 + idx,
                    }}
                    onClick={() => setLightboxImage(img)}
                  >
                    <img 
                      src={img} 
                      alt="Gallery" 
                      className="h-full w-auto object-contain transition-transform duration-700 group-hover:scale-[1.03]" 
                    />
                  </motion.div>
                );
              })}
            </div>
        </div>

        {/* Right: Resources Column */}
        <div className="flex-none w-full md:w-28 lg:w-40 space-y-6 border-l border-[#2D1B69]/10 pl-6 hidden md:block">
          <h4 className="text-[10px] font-bold text-[#2D1B69]/40 uppercase tracking-[0.3em]">RESOURCES</h4>
          <div className="flex flex-col gap-4">
            {project.externalLinks?.map((link, i) => (
              <a 
                key={i} 
                href={link.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[10px] lg:text-xs font-bold uppercase tracking-widest text-[#D4447A] hover:text-[#2D1B69] border-b border-transparent hover:border-[#2D1B69] transition-all w-fit"
              >
                {link.label}
              </a>
            ))}
            {(!project.externalLinks || project.externalLinks.length === 0) && (
              <span className="text-[10px] italic text-stone-400">Archive Only</span>
            )}
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(45, 27, 105, 0.05);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #D4447A;
        }
      `}</style>
    </motion.main>
  );
};

export default ProjectDetail;