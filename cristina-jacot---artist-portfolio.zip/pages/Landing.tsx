
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CONTENT_STORE } from '../constants';

interface LandingProps {
  onEnter: () => void;
}

const Landing: React.FC<LandingProps> = ({ onEnter }) => {
  const [isTransitioning, setIsTransitioning] = useState(false);

  const handleEnter = () => {
    setIsTransitioning(true);
    setTimeout(onEnter, 800);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#D4447A] overflow-hidden">
      {/* Shutter Effect - Updated to match the monochromatic pink flow */}
      <AnimatePresence>
        {isTransitioning && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-[#D4447A] z-[110]"
            transition={{ duration: 0.8, ease: "circIn" }}
          />
        )}
      </AnimatePresence>

      <div className="max-w-4xl text-center px-6">
        <motion.h2
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="header-font text-5xl md:text-7xl lg:text-8xl text-white leading-none mb-6"
        >
          {CONTENT_STORE.landing.line1}
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 1 }}
          className="text-lg md:text-xl text-white/80 font-medium max-w-2xl mx-auto leading-relaxed"
        >
          {CONTENT_STORE.landing.line2}
        </motion.p>

        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          onClick={handleEnter}
          className="mt-16 px-12 py-5 bg-white text-[#D4447A] text-sm font-bold uppercase tracking-[0.3em] hover:bg-[#2D1B69] hover:text-white transition-all duration-300"
        >
          {CONTENT_STORE.landing.buttonText}
        </motion.button>
      </div>
    </div>
  );
};

export default Landing;
