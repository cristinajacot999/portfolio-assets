import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { CONTENT_STORE } from '../constants';

const About: React.FC = () => {
  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen pt-32 pb-12 px-6 md:px-12 bg-[#2D1B69] text-white"
    >
      <div className="max-w-screen-xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        <div className="lg:col-span-8 space-y-12">
          <motion.h2 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="header-font text-5xl md:text-8xl leading-none tracking-tighter uppercase"
          >
            Experience <br/><span className="text-[#D4447A]">architect.</span>
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-6 text-lg font-medium opacity-90 leading-relaxed whitespace-pre-wrap">
              {CONTENT_STORE.about.text}
            </div>
            
            <div className="space-y-8">
               <div className="border-t border-white/20 pt-8">
                 <h4 className="text-[10px] font-bold text-[#D4447A] uppercase tracking-widest mb-4">Enquiries</h4>
                 <Link 
                  to="/contact" 
                  className="inline-block bg-[#D4447A] text-white px-8 py-3 text-xs font-bold uppercase tracking-[0.2em] hover:bg-white hover:text-[#2D1B69] transition-all"
                 >
                   Contact Me
                 </Link>
                 
                 <div className="mt-8 space-y-4">
                   <a 
                    href="https://www.instagram.com/fata.cu.caii" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="flex items-center gap-3 text-xs font-bold hover:text-[#D4447A] transition-colors tracking-widest group"
                   >
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="group-hover:scale-110 transition-transform"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line></svg>
                     fata.cu.caii
                   </a>
                   <a 
                    href="https://www.linkedin.com/in/cristina-jacot" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="flex items-center gap-3 text-xs font-bold hover:text-[#D4447A] transition-colors tracking-widest group"
                   >
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="group-hover:scale-110 transition-transform"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
                     cristina-jacot
                   </a>
                 </div>
               </div>
            </div>
          </div>
        </div>

        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="lg:col-span-4 relative"
        >
          <div className="absolute -inset-4 bg-[#D4447A] -z-10" />
          <img 
            src={CONTENT_STORE.about.image} 
            alt="Artist Profile" 
            className="w-full hover:scale-[1.02] transition-all duration-700 shadow-2xl"
          />
        </motion.div>
      </div>
    </motion.main>
  );
};

export default About;