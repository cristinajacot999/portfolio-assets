import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { CONTENT_STORE } from '../constants';
import { Project, Category } from '../types';

const Home: React.FC = () => {
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const categories: Category[] = [
    'Moving Image',
    'Sonic Cartography',
    'Social Infrastructure',
    'Habitats'
  ];

  // Helper to get first few sentences for the typewriter snippet
  const getSnippet = (text: string) => {
    const sentences = text.split(/[.!?]/);
    return sentences.slice(0, 2).join('.') + (sentences.length > 2 ? '...' : '.');
  };

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen pt-32 pb-12 px-6 md:px-12 flex flex-col relative"
    >
      {/* Fixed Preview Zone (Polaroid) */}
      <AnimatePresence>
        {activeProject && (
          <motion.div
            initial={{ opacity: 0, x: 50, rotate: 2 }}
            animate={{ opacity: 1, x: 0, rotate: -2 }}
            exit={{ opacity: 0, x: 50 }}
            // Polaroid Styling: Significantly more whitespace below (pb-16 vs px-4/pt-4)
            className="fixed right-12 top-1/2 -translate-y-1/2 z-10 hidden xl:block w-[400px] bg-white px-4 pt-4 pb-20 shadow-[20px_20px_0px_0px_rgba(45,27,105,1)]"
          >
            <div className="aspect-[4/5] overflow-hidden bg-stone-200 relative">
              <img 
                src={activeProject.imageUrl} 
                alt={activeProject.title}
                // Global Polaroid Aesthetic: Unified wash, haze, grain
                // Dynamic positioning based on project data
                className={`w-full h-full object-cover contrast-[0.9] brightness-[1.05] sepia-[0.3] saturate-[0.8] blur-[0.5px] ${
                  activeProject.imagePosition === 'left' ? 'object-left' : 
                  activeProject.imagePosition === 'right' ? 'object-right' : 'object-center'
                }`}
              />
              {/* Grain & Wash Overlay */}
              <div className="absolute inset-0 bg-[#E6D5B8]/10 mix-blend-multiply pointer-events-none" />
              <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%' height='100%' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }} />
            </div>
            <div className="absolute top-0 left-0 w-full h-full bg-white/10 pointer-events-none mix-blend-overlay" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Description Snippet (Typewriter) */}
      <div className="fixed bottom-24 left-6 md:left-12 z-20 w-72 md:w-96 pointer-events-none">
        <AnimatePresence mode="wait">
          {activeProject && (
            <motion.div
              key={activeProject.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-3"
            >
              <div className="text-white text-[0.8rem] tracking-widest font-medium opacity-80" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                {activeProject.year}
              </div>
              <div className="w-12 h-[2px] bg-white/40" />
              <p className="text-white text-xs md:text-sm leading-relaxed tracking-tight font-medium text-justify" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                {getSnippet(activeProject.longDescription)}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 h-full">
        {categories.map((cat) => (
          <div key={cat} className="space-y-6">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-white/50 border-b border-white/20 pb-3 flex items-center gap-2">
              <span className="w-2 h-2 bg-white rounded-full" />
              {cat}
            </h2>
            <div className="flex flex-col gap-2">
              {CONTENT_STORE.projects
                .filter((p) => p.category === cat)
                .map((project) => (
                  <Link
                    key={project.id}
                    to={`/project/${project.id}`}
                    onMouseEnter={() => setActiveProject(project)}
                    onMouseLeave={() => setActiveProject(null)}
                    className="group relative"
                  >
                    <motion.div
                      whileHover={{ x: 10 }}
                      className="py-2 flex items-center justify-between group-hover:bg-[#2D1B69] px-2 transition-colors duration-200"
                    >
                      <h3 className="header-font text-xl md:text-2xl text-white group-hover:text-white leading-none whitespace-nowrap overflow-hidden text-ellipsis">
                        {project.title}
                      </h3>
                      <span className="text-[10px] text-white/30 group-hover:text-white/80 opacity-0 group-hover:opacity-100 transition-opacity">
                        →
                      </span>
                    </motion.div>
                  </Link>
                ))}
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-auto pt-12 text-[10px] text-white/30 uppercase tracking-widest font-bold">
        All projects archived 2018-2025
      </div>
    </motion.main>
  );
};

export default Home;